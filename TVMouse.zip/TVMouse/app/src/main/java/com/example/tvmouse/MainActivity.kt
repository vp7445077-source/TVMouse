package com.example.tvmouse

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.*
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.*
import java.util.concurrent.Executors
import kotlin.math.abs

@SuppressLint("MissingPermission")
class MainActivity : Activity() {

    private var hid: BluetoothHidDevice? = null
    private var host: BluetoothDevice? = null
    private lateinit var status: TextView
    private val executor = Executors.newSingleThreadExecutor()

    // ---- HID descriptor: Report ID 1 = Mouse, Report ID 2 = Consumer keys ----
    private val descriptor = byteArrayOf(
        // Mouse
        0x05, 0x01, 0x09, 0x02, 0xA1.toByte(), 0x01, 0x85.toByte(), 0x01,
        0x09, 0x01, 0xA1.toByte(), 0x00,
        0x05, 0x09, 0x19, 0x01, 0x29, 0x03, 0x15, 0x00, 0x25, 0x01,
        0x95.toByte(), 0x03, 0x75, 0x01, 0x81.toByte(), 0x02,
        0x95.toByte(), 0x01, 0x75, 0x05, 0x81.toByte(), 0x03,
        0x05, 0x01, 0x09, 0x30, 0x09, 0x31, 0x09, 0x38,
        0x15, 0x81.toByte(), 0x25, 0x7F, 0x75, 0x08, 0x95.toByte(), 0x03, 0x81.toByte(), 0x06,
        0xC0.toByte(), 0xC0.toByte(),
        // Consumer control: VolUp, VolDown, Mute, Home, Back
        0x05, 0x0C, 0x09, 0x01, 0xA1.toByte(), 0x01, 0x85.toByte(), 0x02,
        0x15, 0x00, 0x25, 0x01, 0x75, 0x01, 0x95.toByte(), 0x05,
        0x09, 0xE9.toByte(), 0x09, 0xEA.toByte(), 0x09, 0xE2.toByte(),
        0x0A, 0x23, 0x02, 0x0A, 0x24, 0x02,
        0x81.toByte(), 0x02,
        0x95.toByte(), 0x01, 0x75, 0x03, 0x81.toByte(), 0x03,
        0xC0.toByte()
    )

    private val callback = object : BluetoothHidDevice.Callback() {
        override fun onConnectionStateChanged(device: BluetoothDevice, state: Int) {
            runOnUiThread {
                when (state) {
                    BluetoothProfile.STATE_CONNECTED -> { host = device; status.text = "Connected: ${device.name}" }
                    BluetoothProfile.STATE_DISCONNECTED -> { if (host == device) host = null; status.text = "Disconnected" }
                    else -> status.text = "Connecting..."
                }
            }
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        buildUi()
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT,
                Manifest.permission.BLUETOOTH_ADVERTISE), 1)
        } else startHid()
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        if (r.isNotEmpty() && r.all { it == PackageManager.PERMISSION_GRANTED }) startHid()
        else status.text = "Bluetooth permission chahiye"
    }

    private fun startHid() {
        val adapter = (getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
        adapter.getProfileProxy(this, object : BluetoothProfile.ServiceListener {
            override fun onServiceConnected(profile: Int, proxy: BluetoothProfile) {
                hid = proxy as BluetoothHidDevice
                val sdp = BluetoothHidDeviceAppSdpSettings(
                    "TV Mouse", "Phone as mouse", "TVMouse",
                    BluetoothHidDevice.SUBCLASS1_COMBO, descriptor)
                hid?.registerApp(sdp, null, null, executor, callback)
                runOnUiThread { status.text = "Ready. Pehle 'Discoverable' dabaye" }
            }
            override fun onServiceDisconnected(profile: Int) { hid = null }
        }, BluetoothProfile.HID_DEVICE)
    }

    // ---- Sending ----
    private fun mouse(buttons: Int, dx: Int, dy: Int, wheel: Int = 0) {
        val h = host ?: return
        hid?.sendReport(h, 1, byteArrayOf(buttons.toByte(),
            dx.coerceIn(-127, 127).toByte(), dy.coerceIn(-127, 127).toByte(),
            wheel.coerceIn(-127, 127).toByte()))
    }

    private fun click(button: Int) { mouse(button, 0, 0); mouse(0, 0, 0) }

    private fun consumer(bit: Int) {
        val h = host ?: return
        hid?.sendReport(h, 2, byteArrayOf(bit.toByte()))
        hid?.sendReport(h, 2, byteArrayOf(0))
    }

    // ---- UI ----
    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 48, 24, 24) }
        status = TextView(this).apply { text = "Starting..."; textSize = 16f }
        root.addView(status)

        root.addView(row(
            btn("Discoverable") {
                startActivity(Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE)
                    .putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300))
            },
            btn("Connect TV") { pickDevice() }
        ))

        val pad = Trackpad(this)
        root.addView(pad, LinearLayout.LayoutParams(-1, 0, 1f).apply { setMargins(0, 16, 0, 16) })

        root.addView(row(btn("Left Click") { click(1) }, btn("Right Click") { click(2) }))
        root.addView(row(btn("Back") { consumer(0x10) }, btn("Home") { consumer(0x08) }))
        root.addView(row(btn("Vol -") { consumer(0x02) }, btn("Mute") { consumer(0x04) }, btn("Vol +") { consumer(0x01) }))
        setContentView(root)
    }

    private fun btn(t: String, onClick: () -> Unit) =
        Button(this).apply { text = t; setOnClickListener { onClick() } }

    private fun row(vararg v: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        v.forEach { addView(it, LinearLayout.LayoutParams(0, -2, 1f)) }
    }

    private fun pickDevice() {
        val list = (getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager)
            .adapter.bondedDevices.toList()
        if (list.isEmpty()) { status.text = "Koi paired device nahi. TV se pair karein."; return }
        AlertDialog.Builder(this).setTitle("TV chunein")
            .setItems(list.map { it.name ?: it.address }.toTypedArray()) { _, i ->
                status.text = "Connecting..."
                hid?.connect(list[i])
            }.show()
    }

    // ---- Trackpad ----
    inner class Trackpad(c: Context) : View(c) {
        private var lx = 0f; private var ly = 0f
        private var downTime = 0L; private var moved = 0f
        private var maxPointers = 1
        private val speed = 1.8f

        init { setBackgroundColor(Color.LTGRAY) }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { lx = e.x; ly = e.y; downTime = e.eventTime; moved = 0f; maxPointers = 1 }
                MotionEvent.ACTION_POINTER_DOWN -> { maxPointers = maxOf(maxPointers, e.pointerCount); lx = e.x; ly = e.y }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.x - lx; val dy = e.y - ly
                    lx = e.x; ly = e.y
                    moved += abs(dx) + abs(dy)
                    if (e.pointerCount >= 2) mouse(0, 0, 0, (-dy / 4).toInt())   // 2-finger scroll
                    else mouse(0, (dx * speed).toInt(), (dy * speed).toInt())
                }
                MotionEvent.ACTION_UP -> {
                    if (moved < 20 && e.eventTime - downTime < 250)
                        click(if (maxPointers >= 2) 2 else 1)  // tap = left, 2-finger tap = right
                }
            }
            return true
        }
    }
}
